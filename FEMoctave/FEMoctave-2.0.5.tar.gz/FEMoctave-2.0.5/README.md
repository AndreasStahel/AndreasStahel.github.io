# FEMoctave: a simple FEM package to use FEM  for solving boundary value problems in two space dimensions

## CONTENTS:

1. HISTORY
2. INSTALLATION INSTRUCTIONS
3. DEMOS AND EXAMPLEs

## 1. HISTORY

The first version of FEMoctave was written in 2000.
In 2020 a new version was generated.

## 2. INSTALLATION INSTRUCTIONS
To use all features of FEMoctave you have to install triangle.
Find the source code and instructions at
https://www.cs.cmu.edu/~quake/triangle.html

## 3. DEMOS AND EXAMPLES
The subdirectory doc contains many sample codes

With bests regards
Andreas Stahel

